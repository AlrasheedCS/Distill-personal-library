---
type: keeper
area: AI tools
kind: tip
verdict: 'Ask for sources first, summary second'
status: draft
example: false
---

# Ask for sources first

Proposed from [[sources/chats/chatgpt/Deep research vs. my own search]]. Say "keep this" to move it to Keepers.
