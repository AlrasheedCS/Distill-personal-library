---
type: questions-asked
maintained_by: script
topic: 'AI coding workflow'
---

# Questions asked: AI coding workflow

1 questions from 1 chats. Each links to the exact prompt in its chat note. Rebuilt by `system/scripts/build_questions.py`; edits here are overwritten.

## [[sources/chats/claude/Prompts for code review|Prompts for code review]] · Claude

- [[sources/chats/claude/Prompts for code review#1. How do I get shorter, more useful AI code reviews?|How do I get shorter, more useful AI code reviews?]]: “Give the model a role and a priority order. Ask for risks first (correctness, security, data loss), then tests, and only then style…”

[[agent/questions/Questions asked|All topics]] · [[Home]]
