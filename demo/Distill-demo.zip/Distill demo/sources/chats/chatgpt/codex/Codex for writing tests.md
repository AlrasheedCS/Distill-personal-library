---
type: chat
kind: code
depth: full
source: codex
chat_id: unknown
about: 'Letting Codex write tests for an old utility module'
main_insight: 'Give it one example test in your style; the rest came out consistent.'
url: 'https://chatgpt.com/'
transcript: ''
saved: '2025-02-10'
chatgpt_project: 'AI coding'
pinned: false
status: kept
review: ''
priority: ''
topics: ['[[agent/topics/AI coding workflow]]']
projects: ['[[projects/AI coding workflow]]']
why_saved: ''
example: false
---

# Codex for writing tests

> [!link] [Open original chat](https://chatgpt.com/) · Full transcript


## Main insight

One example test in your own style made the rest consistent.

