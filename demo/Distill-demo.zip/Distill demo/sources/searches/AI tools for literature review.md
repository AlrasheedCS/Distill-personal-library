---
type: search
kind: search
source: ai-search
about: 'Which AI tools help with a literature review, and where they fail'
saved: '2025-02-09'
status: kept
projects: ['[[projects/Research faster with AI]]']
topics: []
example: false
---

# AI tools for literature review

## Main insight

Good for finding and sorting papers; weak at judging study quality.

## Key insights

- Both outputs agreed: always open the paper before citing it.
- They disagreed on how far to trust automatic summaries. Kept both views.
