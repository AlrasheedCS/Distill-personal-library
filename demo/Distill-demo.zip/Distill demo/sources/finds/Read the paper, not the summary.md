---
type: find
kind: find
source: x
author: 'Example Author'
url: 'https://example.com/post'
about: 'Why AI summaries are a starting point'
published: unknown
saved: '2025-02-05'
captured_via: share sheet
projects: ['[[projects/Research faster with AI]]']
topics: []
status: filed
review: ''
priority: ''
example: false
---

# Read the paper, not the summary

> [!link] [Open the original](https://example.com/post) · Example Author

## The post

> Why AI summaries are a starting point.

## My take

Fits how I already work.
