---
type: project
saved: '2025-02-01'
status: active
topics: []
projects: []
example: false
---

# Research faster with AI

## Outcome

Answer research questions in half the time without trusting invented sources.

## Next action

- [ ] Test the deep-research prompt on one real question.

## My notes and highlights

==Ask for sources first, summary second.==

## Ideas

> [!ai] Proposed ideas
> - Save the research prompt that worked as a keeper · from [[sources/chats/chatgpt/Deep research vs. my own search]]

## Research for this project

```base
filters:
  and:
  - file.hasLink(this.file)
  - or:
    - type == "paper"
    - type == "search"
properties:
  file.name:
    displayName: Paper or search
  about:
    displayName: About
views:
- type: table
  name: Research for this project
  order:
  - file.name
  - type
  - about
```

## Finds for this project

%% Any find whose `projects` property links this note shows up here automatically. %%

```base
filters:
  and:
  - file.hasLink(this.file)
  - type == "find"
properties:
  file.name:
    displayName: Find
  about:
    displayName: About
views:
- type: table
  name: Finds for this project
  order:
  - file.name
  - about
  - author
  - saved
  sort:
  - property: saved
    direction: DESC
```

## Chats in this project

%% Any chat whose `projects` property links this note shows up here automatically. %%

```base
filters:
  and:
  - file.hasLink(this.file)
  - type == "chat"
properties:
  file.name:
    displayName: Chat
  about:
    displayName: About
  source:
    displayName: From
views:
- type: table
  name: Chats in this project
  order:
  - file.name
  - about
  - source
  - saved
  sort:
  - property: saved
    direction: DESC
```

## Supporting notes

## Decisions

## Done when
