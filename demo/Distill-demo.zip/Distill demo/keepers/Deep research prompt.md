---
type: keeper
area: AI tools
kind: prompt
verdict: 'Sources first, summary second, every claim linked'
confirmed: '2025-02-20'
recheck: '2025-03-01'
sources: []
status: current
saved: '2025-02-21'
example: false
---

# Deep research prompt

## The finding

Sources first, summary second, every claim linked.
