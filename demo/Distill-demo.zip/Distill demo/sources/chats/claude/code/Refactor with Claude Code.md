---
type: chat
kind: code
depth: full
source: claude-code
chat_id: unknown
about: 'Splitting a 900-line module into four files without breaking tests'
main_insight: 'Write the plan to a file first; Claude Code followed it and the tests stayed green.'
url: 'https://claude.ai/'
transcript: ''
saved: '2025-02-06'
chatgpt_project: 'AI coding'
pinned: false
status: kept
review: ''
priority: ''
topics: ['[[agent/topics/AI coding workflow]]']
projects: ['[[projects/AI coding workflow]]']
why_saved: ''
example: false
---

# Refactor with Claude Code

> [!link] [Open original chat](https://claude.ai/) · Full transcript


## About

**Goal:** split a 900-line module into four files.
**Outcome:** worked, in one session.

## Main insight

A written plan in `PLAN.md` kept the refactor on track.

## Decisions

- Plan first, then code. Rejected: one big "refactor this" prompt.

## What broke and the fix

- An import cycle after the split. Fix: move shared types to their own file.

