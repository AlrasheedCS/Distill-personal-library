---
type: keeper
area: Work
kind: tip
verdict: 'Table of owner, task, date; “unknown” when missing'
confirmed: '2025-02-20'
recheck: ''
sources: []
status: current
saved: '2025-02-23'
example: false
---

# Meeting notes to tasks

## The finding

Table of owner, task, date; “unknown” when missing.
