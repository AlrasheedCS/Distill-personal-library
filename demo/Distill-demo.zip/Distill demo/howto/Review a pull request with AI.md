---
type: howto
saved: '2025-02-22'
status: kept
review: ''
priority: ''
tested: true
source_chats: ['[[sources/chats/claude/Prompts for code review]]']
topics: []
example: false
---

# Review a pull request with AI

## Goal

A short review that catches real risks.

## Steps

1. Paste the diff.
2. Use the [[keepers/Code review prompt|code review prompt]].
3. Fix the top risk first.
