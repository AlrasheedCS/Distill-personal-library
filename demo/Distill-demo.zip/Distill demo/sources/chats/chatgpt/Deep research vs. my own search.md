---
type: chat
kind: project
depth: full
source: chatgpt
chat_id: unknown
about: 'Comparing an AI deep-research report with an hour of my own searching'
main_insight: 'Deep research found more sources; my search found the better ones. Use both, sources first.'
url: 'https://chatgpt.com/'
transcript: ''
saved: '2025-02-08'
chatgpt_project: 'AI research'
pinned: false
status: kept
review: ''
priority: ''
topics: ['[[agent/topics/AI coding workflow]]']
projects: ['[[projects/Research faster with AI]]']
why_saved: ''
example: false
---

# Deep research vs. my own search

> [!link] [Open original chat](https://chatgpt.com/) · Full transcript


## Main insight

Deep research found more sources; my own search found the better ones.

## My highlights

==Ask for sources first, summary second.==

