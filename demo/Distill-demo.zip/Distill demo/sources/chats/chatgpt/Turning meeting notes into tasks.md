---
type: chat
kind: chat
depth: full
source: chatgpt
chat_id: unknown
about: 'A prompt that turns messy meeting notes into owners and dates'
main_insight: 'Ask for a table with owner, task and date, and “unknown” where it’s missing.'
url: 'https://chatgpt.com/'
transcript: ''
saved: '2025-02-14'
chatgpt_project: ''
pinned: false
status: kept
review: ''
priority: ''
topics: ['[[agent/topics/AI coding workflow]]']
projects: []
why_saved: ''
example: false
---

# Turning meeting notes into tasks

> [!link] [Open original chat](https://chatgpt.com/) · Full transcript


## Main insight

Ask for a table (owner, task, date) and "unknown" where it's missing.

