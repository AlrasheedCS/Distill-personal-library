---
type: status
maintained_by: script
---

# Status

Rebuilt by `system/scripts/build_status.py` whenever an AI runs the rebuild scripts (not live). Last rebuilt 2026-11-11.

## To sort

📥 **[[inbox/to sort|To sort]]**: about 3 captures waiting · say "sort my inbox" to file them

## Drafts

🗂 3 AI drafts waiting for you (how-tos, prompts, ideas, questions): see *Waiting for you* below
