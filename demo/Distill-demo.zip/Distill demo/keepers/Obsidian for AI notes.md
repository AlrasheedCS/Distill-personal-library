---
type: keeper
area: Learning
kind: pick
verdict: 'Obsidian + Bases: plain files any AI can read'
confirmed: '2025-02-20'
recheck: '2025-08-01'
sources: []
status: current
saved: '2025-02-24'
example: false
---

# Obsidian for AI notes

## The finding

Obsidian + Bases: plain files any AI can read.
