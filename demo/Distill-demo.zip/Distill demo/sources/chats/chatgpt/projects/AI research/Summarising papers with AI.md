---
type: chat
kind: project
depth: full
source: chatgpt
chat_id: unknown
about: 'Getting reliable paper summaries without invented numbers'
main_insight: 'Ask it to quote numbers exactly with page numbers, and label its own conclusions.'
url: 'https://chatgpt.com/'
transcript: ''
saved: '2025-02-18'
chatgpt_project: 'AI research'
pinned: false
status: kept
review: ''
priority: ''
topics: ['[[agent/topics/AI coding workflow]]']
projects: ['[[projects/Research faster with AI]]']
why_saved: ''
example: false
---

# Summarising papers with AI

> [!link] [Open original chat](https://chatgpt.com/) · Full transcript


## Main insight

Quote numbers exactly with page numbers; label your own conclusions.

