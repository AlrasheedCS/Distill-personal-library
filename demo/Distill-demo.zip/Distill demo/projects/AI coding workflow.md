---
type: project
saved: '2025-02-01'
status: active
topics: []
projects: []
example: false
---

# AI coding workflow

## Outcome

A calm, repeatable way to code with AI: plan, small commits, real reviews.

## Next action

- [ ] Use the code-review prompt on the next three pull requests.

## My notes and highlights

Plan first. Small commits. Review every diff.

## Ideas

> [!ai] Proposed ideas
> - Turn the weekly report into a skill · from [[sources/chats/claude/Building a weekly-report skill]]

## Research for this project

```base
filters:
  and:
  - file.hasLink(this.file)
  - or:
    - type == "paper"
    - type == "search"
properties:
  file.name:
    displayName: Paper or search
  about:
    displayName: About
views:
- type: table
  name: Research for this project
  order:
  - file.name
  - type
  - about
```

## Finds for this project

%% Any find whose `projects` property links this note shows up here automatically. %%

```base
filters:
  and:
  - file.hasLink(this.file)
  - type == "find"
properties:
  file.name:
    displayName: Find
  about:
    displayName: About
views:
- type: table
  name: Finds for this project
  order:
  - file.name
  - about
  - author
  - saved
  sort:
  - property: saved
    direction: DESC
```

## Chats in this project

%% Any chat whose `projects` property links this note shows up here automatically. %%

```base
filters:
  and:
  - file.hasLink(this.file)
  - type == "chat"
properties:
  file.name:
    displayName: Chat
  about:
    displayName: About
  source:
    displayName: From
views:
- type: table
  name: Chats in this project
  order:
  - file.name
  - about
  - source
  - saved
  sort:
  - property: saved
    direction: DESC
```

## Supporting notes

## Decisions

## Done when
