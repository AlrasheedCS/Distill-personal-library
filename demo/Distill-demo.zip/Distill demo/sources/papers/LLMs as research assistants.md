---
type: paper
kind: paper
title: 'LLMs as research assistants'
authors: ['A. Example', 'B. Sample']
year: 2025
venue: 'Example Journal'
url: 'https://example.com/paper'
doi: ''
about: 'How well language models help with literature search and summaries'
main_finding: 'Helpful for search and first drafts; error rates rose on numbers and citations.'
saved: '2025-02-11'
read: true
status: kept
review: ''
priority: ''
topics: []
projects: ['[[projects/Research faster with AI]]']
example: false
---

# LLMs as research assistants

> [!link] [Open the paper](https://example.com/paper) · A. Example, B. Sample (2025)

## Main finding

Helpful for search and first drafts; errors rose on numbers and citations.

## My highlights

==Always check numbers against the original table.== (p. 6)

> [!ai] AI summary
> - [source] Most errors were in quoted numbers and citations.
> - [inferred] Matches the advice in [[sources/chats/chatgpt/projects/AI research/Summarising papers with AI]].
