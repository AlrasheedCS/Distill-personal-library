---
type: keeper
area: AI tools
kind: prompt
verdict: 'Risks first, style last, stop if nothing is risky'
confirmed: '2025-02-20'
recheck: ''
sources: []
status: current
saved: '2025-02-20'
example: false
---

# Code review prompt

## The finding

Risks first, style last, stop if nothing is risky.
