---
type: guide
summary: "Hub of AI-maintained topic maps."
---

# Topics (AI)

AI-maintained topic maps: a summary per topic with links to the chats behind each point. Every line on a topic page is labelled `[source]`, `[inferred]`, `[mine]` or `[verified]`. Your own topic notes live in [[topics/Topics]].

- [[agent/topics/AI coding workflow|AI coding workflow]] (4 chats)
