---
type: find
kind: find
source: x
author: 'Example Author'
url: 'https://example.com/post'
about: 'Ask for small, reviewable changes'
published: unknown
saved: '2025-02-05'
captured_via: share sheet
projects: ['[[projects/AI coding workflow]]']
topics: []
status: filed
review: ''
priority: ''
example: false
---

# Small commits beat big prompts

> [!link] [Open the original](https://example.com/post) · Example Author

## The post

> Ask for small, reviewable changes.

## My take

Fits how I already work.
