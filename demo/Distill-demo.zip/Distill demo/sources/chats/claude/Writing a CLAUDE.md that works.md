---
type: chat
kind: chat
depth: full
source: claude
chat_id: unknown
about: 'What to put in a CLAUDE.md so sessions start right'
main_insight: 'Short beats long: commands, conventions, and what not to touch.'
url: 'https://claude.ai/'
transcript: ''
saved: '2025-02-12'
chatgpt_project: ''
pinned: false
status: kept
review: ''
priority: ''
topics: ['[[agent/topics/AI coding workflow]]']
projects: ['[[projects/AI coding workflow]]']
why_saved: ''
example: false
---

# Writing a CLAUDE.md that works

> [!link] [Open original chat](https://claude.ai/) · Full transcript


## Main insight

Short beats long: the commands, the conventions, and what not to touch.

