---
type: questions-asked
maintained_by: script
summary: 'Every question you asked in your chats, by topic, linked to where you asked it.'
---

# Questions asked

Every question you've asked in your chats: **1 prompts** across 1 chats, grouped by topic. Each one links to the exact place in its chat. Use it to find an earlier answer before asking again, or to spot what you keep asking about.

> [!tip] Search inside one topic with Cmd+F, or across all with Omnisearch: `path:agent/questions/asked`.

| Topic | Questions | Chats |
| --- | --- | --- |
| [[agent/questions/asked/AI coding workflow\|AI coding workflow]] | 1 | 1 |

Unresolved questions are a separate list: [[agent/questions/Open questions]].

Rebuilt by `system/scripts/build_questions.py`; edits here are overwritten.

[[Home]]
