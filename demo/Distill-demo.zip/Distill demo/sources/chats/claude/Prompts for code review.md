---
type: chat
kind: project
depth: full
source: claude
chat_id: unknown
about: 'Getting an AI to review a diff like a careful senior engineer'
main_insight: 'Ask for risks before style nits: reviews got shorter and caught more real bugs.'
url: 'https://claude.ai/'
transcript: ''
saved: '2025-02-03'
chatgpt_project: 'AI coding'
pinned: true
status: kept
review: ''
priority: ''
topics: ['[[agent/topics/AI coding workflow]]']
projects: ['[[projects/AI coding workflow]]']
why_saved: ''
example: false
---

# Prompts for code review

> [!link] [Open original chat](https://claude.ai/) · Full transcript


## About

**Started as:** "My AI code reviews are long and mostly about formatting."
**Turned into:** a two-step review prompt that lists risks first.

## Main insight

Ask the AI to list **risks before style nits**. Reviews got shorter and caught more real bugs.

## My highlights

==Review this diff as a sceptical senior engineer. List the three riskiest changes first.==

==If nothing is risky, say so in one line and stop.==

> [!ai] Why it matters
> - [inferred] Worth saving as a prompt: it's the same pattern as "plan first, then code". Drafted for your prompt library.

## Prompts and answers

### 1. How do I get shorter, more useful AI code reviews?

> Give the model a role and a priority order. Ask for risks first (correctness, security, data loss), then tests, and only then style…

## More

### Next actions

- [ ] Try it on the next three pull requests.

