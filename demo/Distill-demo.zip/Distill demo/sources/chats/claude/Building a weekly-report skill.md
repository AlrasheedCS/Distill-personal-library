---
type: chat
kind: chat
depth: full
source: claude
chat_id: unknown
about: 'Packaging a weekly status report as a reusable Claude skill'
main_insight: 'A skill with one template file beat a long prompt pasted every Friday.'
url: 'https://claude.ai/'
transcript: ''
saved: '2025-02-16'
chatgpt_project: ''
pinned: false
status: kept
review: 'to review'
priority: high
topics: ['[[agent/topics/AI coding workflow]]']
projects: ['[[projects/AI coding workflow]]']
why_saved: ''
example: false
---

# Building a weekly-report skill

> [!link] [Open original chat](https://claude.ai/) · Full transcript


## Main insight

A skill with one template file beat a long prompt pasted every Friday.

