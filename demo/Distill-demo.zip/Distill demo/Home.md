---
cssclasses:
- home
type: dashboard
---

# Distill

Your library: AI chats, research and papers, finds from your feed, and the how-tos, prompts and keepers drawn from them. What this vault is for: [[system/About Distill|About]] · every note: [[system/Index|Index]] · for a new AI chat: [[system/Handoff|Handoff]] · why it's built this way: [[system/Decisions|Decisions]].

> [!tip] Chat homes
> [[ChatGPT home|ChatGPT & Codex]] · [[Claude home|Claude & Claude Code]] · [[Chats|All chats]]
> Searches (not chats): [[sources/searches/Searches|Searches]] · Finds from your feed: [[sources/finds/Finds|Finds]]
> ![[agent/status#To sort]]
> 🔎 Quick searches: [Code sessions](obsidian://search?vault=Distill&query=%5Bkind%3Acode%5D) · [Finds](obsidian://search?vault=Distill&query=%5Btype%3Afind%5D) · [My ==highlights==](obsidian://search?vault=Distill&query=/%3D%3D%5B%5E%3D%5Cn%5D%2B%3D%3D/) · [My [!mine] comments](obsidian://search?vault=Distill&query=%22%5B%21mine%5D%22) · [High priority](obsidian://search?vault=Distill&query=%5Bpriority%3Ahigh%5D)
> ⭐ **[[keepers/Keepers|Keepers]]**: your best-of shelf, final findings in every area (only you change it)
> **[[agent/questions/Questions asked|Questions asked]]**: every question from your chats, by topic
> **[[agent/trails/Trails to follow|Trails to follow]]**: links your chats pointed to, to read more on
> **Projects**: [[projects/AI coding workflow|AI coding workflow]] · [[projects/Research faster with AI|Research faster with AI]] · [[projects/Projects|all projects]]
> AI-maintained: [[agent/topics/Topics|Topics]] · [[agent/questions/Open questions|Open questions]] · [[agent/index|Wiki & index]]

## Recent chats

![[system/bases/Home.base#Recent chats]]

## Waiting for you

Drafts Claude made from your chats. Open one, then keep, edit or skip it.

![[system/bases/Home.base#Waiting for review]]

## Recently kept

![[system/bases/Home.base#Recently kept]]

## Scope of this vault


> [!abstract] What this vault is for
> **My library for working with AI.** What I learn from AI chats, research and papers, kept so I can find it and reuse it.
>
> **Belongs here**
> 1. **AI chats** worth keeping (ChatGPT, Claude, Codex, Claude Code), only ones I approve.
> 2. **Research and papers**: AI searches, deep-research reports and the papers behind them.
> 3. **Finds** from my feed about AI workflows.
> 4. **Projects**, **how-tos**, **prompts** and **keepers** drawn from all of it.
>
> **Rules I care about**
> - Nothing comes in automatically. AIs add; they change things only with my OK.
> - My highlights and keepers are mine.

| Find                      | Keep                            | Think                              |
| ------------------------- | ------------------------------- | ---------------------------------- |
| [[Chats\|Saved chats]]    | [[howto/How-tos\|How-tos]]      | [[questions/Questions\|Questions]] |
| [[topics/Topics\|Topics]] | [[prompts/Prompts\|Prompts]]    | [[ideas/Ideas\|Ideas]]             |
| [[inbox/to sort\|To sort]]  | [[projects/Projects\|Projects]] | [[agent/index\|Agent wiki]]        |

## Marked to review

Anything you set to `review: to review`, grouped by priority.

![[system/bases/Home.base#Marked to review]]

## How-tos to test

Tick `tested` once you've done it and it worked.

![[system/bases/Home.base#How-tos to test]]

## Pinned chats

![[system/bases/Saved chats.base#Pinned]]

> [!note]- Guides and setup
> [[Start here]] · [[system/Capture chats|Save a chat]] · [[system/Weekly reset|Weekly reset]] · [[system/How this vault works|How this works]] · [[system/Property guide|Properties]] · [[system/Setup and appearance|Appearance and tools]] · [[system/Improve later|Improve later]] · [[system/Known issues|Known issues]] · [[system/Features|Features]] · [[Library|Source library]]

