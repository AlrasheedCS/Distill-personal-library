---
type: topic
summary: "What your saved chats say about coding with AI."
---

# AI coding workflow

AI topic map, built from your saved chats. Every line says where it comes from.

## Summary

- [source] Plan first, then code: a written plan kept a large refactor on track · [[sources/chats/claude/code/Refactor with Claude Code]]
- [source] One example test in your style makes AI-written tests consistent · [[sources/chats/chatgpt/codex/Codex for writing tests]]
- [inferred] Your best sessions all started with a short written spec.
- [mine] "Small commits, review every diff" · [[projects/AI coding workflow]]
- [verified] Claude Code reads CLAUDE.md at the start of a session · [docs](https://docs.claude.com/en/docs/claude-code/memory)

> [!warning] Unverified
> - "Longer prompts always give better code": one chat said it, with no source.

## Chats

- [[sources/chats/claude/Prompts for code review]]
- [[sources/chats/claude/code/Refactor with Claude Code]]
- [[sources/chats/chatgpt/codex/Codex for writing tests]]
- [[sources/chats/claude/Writing a CLAUDE.md that works]]
