---
type: find
kind: find
source: x
author: 'Example Author'
url: 'https://example.com/post'
about: 'Send every agent’s output to one review list'
published: unknown
saved: '2025-02-05'
captured_via: share sheet
projects: ['[[projects/AI coding workflow]]']
topics: []
status: filed
review: ''
priority: ''
example: false
---

# One review queue for all your agents

> [!link] [Open the original](https://example.com/post) · Example Author

## The post

> Send every agent’s output to one review list.

## My take

Fits how I already work.
