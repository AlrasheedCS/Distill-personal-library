---
type: keeper
area: Coding
kind: verdict
verdict: 'Write the plan to a file before any big AI change'
confirmed: '2025-02-20'
recheck: ''
sources: []
status: current
saved: '2025-02-25'
example: false
---

# Plan first, then code

## The finding

Write the plan to a file before any big AI change.
