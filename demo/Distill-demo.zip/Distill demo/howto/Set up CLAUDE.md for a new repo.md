---
type: howto
saved: '2025-02-13'
status: kept
review: ''
priority: ''
tested: false
source_chats: ['[[sources/chats/claude/Writing a CLAUDE.md that works]]']
topics: []
example: false
---

# Set up CLAUDE.md for a new repo

## Goal

Sessions that start with the right commands and conventions.

## Steps

1. List build, test and lint commands.
2. Add three conventions and what not to touch.
3. Keep it under 40 lines.
